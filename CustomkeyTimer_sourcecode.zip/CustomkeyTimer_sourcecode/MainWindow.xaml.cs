using System;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Threading;

namespace CooldownApp
{
    public partial class MainWindow : Window
    {
        // --- Config (mutable via Settings panel) ---
        private double _cooldownSeconds = 4.0;
        private const double RingRadius = 105.0;
        private const double RingCenterX = 115.0;
        private const double RingCenterY = 115.0;
        private const int DefaultVkCode = 0x45; // "E"
        private const double MinCooldownSeconds = 1.0;
        private const double MaxCooldownSeconds = 60.0;

        // --- State ---
        private readonly DispatcherTimer _tickTimer;
        private DateTime _cooldownStart;
        private bool _isOnCooldown;
        private bool _eIsPhysicallyDown; // dedupes OS auto-repeat while the trigger key is held
        private bool _isDetectionEnabled = true;
        private bool _isListeningForRebind;
        private int _boundVkCode = DefaultVkCode;
        private Storyboard _pulseStoryboard;
        private GlobalKeyboardHook _keyboardHook;

        public MainWindow()
        {
            InitializeComponent();

            // ~60fps update loop for the arc + countdown text
            _tickTimer = new DispatcherTimer
            {
                Interval = TimeSpan.FromMilliseconds(16)
            };
            _tickTimer.Tick += TickTimer_Tick;

            Loaded += MainWindow_Loaded;
            Closed += MainWindow_Closed;
        }

        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            EnterReadyState();

            // System-wide hook: fires on "E" no matter which window/app has focus,
            // so this works while Roblox (or anything else) is the active window.
            _keyboardHook = new GlobalKeyboardHook();
            _keyboardHook.KeyDown += GlobalKeyboardHook_KeyDown;
            _keyboardHook.KeyUp += GlobalKeyboardHook_KeyUp;
        }

        private void MainWindow_Closed(object sender, EventArgs e)
        {
            _tickTimer.Stop();
            if (_keyboardHook != null)
            {
                _keyboardHook.KeyDown -= GlobalKeyboardHook_KeyDown;
                _keyboardHook.KeyUp -= GlobalKeyboardHook_KeyUp;
                _keyboardHook.Dispose();
            }
        }

        // ---------------- Input ----------------

        private void GlobalKeyboardHook_KeyDown(int vkCode)
        {
            if (_isListeningForRebind)
            {
                Dispatcher.Invoke(() => CompleteRebind(vkCode));
                return;
            }

            if (!_isDetectionEnabled) return;
            if (vkCode != _boundVkCode) return;
            if (_eIsPhysicallyDown) return; // ignore Windows' auto-repeat while held
            _eIsPhysicallyDown = true;

            // Dispatcher.Invoke keeps this safely on the UI thread regardless of
            // exactly how/when the hook callback gets invoked.
            Dispatcher.Invoke(() =>
            {
                if (!_isOnCooldown)
                {
                    StartCooldown();
                }
            });
        }

        private void GlobalKeyboardHook_KeyUp(int vkCode)
        {
            if (vkCode != _boundVkCode) return;
            _eIsPhysicallyDown = false;
        }

        // ---------------- Cooldown flow ----------------

        private void StartCooldown()
        {
            _isOnCooldown = true;
            _cooldownStart = DateTime.Now;

            KeyText.Visibility = Visibility.Collapsed;
            CountdownText.Visibility = Visibility.Visible;
            CountdownText.Text = _cooldownSeconds.ToString("0.0");

            StatusText.Text = "COOLING DOWN...";
            StatusText.Foreground = (Brush)FindResource("CooldownBrush");

            ProgressArc.Stroke = (Brush)FindResource("CooldownBrush");
            ArcGlow.Color = (Color)FindResource("CooldownColor");

            StopPulse();
            SetArcProgress(0);

            _tickTimer.Start();
        }

        private void TickTimer_Tick(object sender, EventArgs e)
        {
            double elapsed = (DateTime.Now - _cooldownStart).TotalSeconds;
            double progress = elapsed / _cooldownSeconds;

            if (progress >= 1.0)
            {
                _tickTimer.Stop();
                EnterReadyState();
                return;
            }

            SetArcProgress(progress);

            double remaining = _cooldownSeconds - elapsed;
            CountdownText.Text = Math.Max(0, remaining).ToString("0.0");
        }

        private void EnterReadyState()
        {
            _isOnCooldown = false;

            KeyText.Visibility = Visibility.Visible;
            CountdownText.Visibility = Visibility.Collapsed;

            if (!_isDetectionEnabled)
            {
                ShowDetectionOffVisuals();
                return;
            }

            StatusText.Text = "PRESS  " + GetKeyDisplayName(_boundVkCode) + "  TO  START";
            StatusText.Foreground = (Brush)FindResource("ReadyBrush");

            ProgressArc.Stroke = (Brush)FindResource("ReadyBrush");
            ArcGlow.Color = (Color)FindResource("ReadyColor");

            SetArcProgress(1.0); // full ring shown while idle/ready
            StartPulse();
        }

        // ---------------- Arc math ----------------

        // progress: 0.0 (no ring) -> 1.0 (full circle)
        private void SetArcProgress(double progress)
        {
            progress = Math.Max(0.0, Math.Min(1.0, progress));

            // Avoid a fully-closed geometry glitch at exactly 0 or 1
            double angleDeg = progress * 359.999;
            double angleRad = angleDeg * Math.PI / 180.0;

            double x = RingCenterX + RingRadius * Math.Sin(angleRad);
            double y = RingCenterY - RingRadius * Math.Cos(angleRad);

            ArcSegmentPart.Point = new Point(x, y);
            ArcSegmentPart.IsLargeArc = angleDeg > 180.0;
        }

        // ---------------- Pulse glow (ready state) ----------------

        private void StartPulse()
        {
            if (_pulseStoryboard == null)
            {
                _pulseStoryboard = (Storyboard)FindResource("PulseStoryboard");
            }
            GlowEllipse.Opacity = 0.35;
            _pulseStoryboard.Begin(this, true);
        }

        private void StopPulse()
        {
            _pulseStoryboard?.Stop(this);
            GlowEllipse.Opacity = 0.15;
        }

        // ---------------- Settings panel ----------------

        private void SettingsButton_Click(object sender, RoutedEventArgs e)
        {
            SettingsOverlay.Visibility = Visibility.Visible;
        }

        private void HelpButton_Click(object sender, RoutedEventArgs e)
        {
            HelpOverlay.Visibility = Visibility.Visible;
        }

        private void HelpCloseButton_Click(object sender, RoutedEventArgs e)
        {
            HelpOverlay.Visibility = Visibility.Collapsed;
        }

        private void SettingsCloseButton_Click(object sender, RoutedEventArgs e)
        {
            if (_isListeningForRebind)
            {
                // Bail out of "press a key" mode without changing the binding
                _isListeningForRebind = false;
                RebindKeyButton.Content = GetKeyDisplayName(_boundVkCode);
            }
            SettingsOverlay.Visibility = Visibility.Collapsed;
        }

        private void DetectionToggle_Changed(object sender, RoutedEventArgs e)
        {
            _isDetectionEnabled = DetectionToggle.IsChecked == true;

            if (!_isDetectionEnabled)
            {
                _tickTimer.Stop();
                _isOnCooldown = false;
                _eIsPhysicallyDown = false;
                StopPulse();
                ShowDetectionOffVisuals();
            }
            else
            {
                EnterReadyState();
            }
        }

        private void ShowDetectionOffVisuals()
        {
            KeyText.Visibility = Visibility.Visible;
            CountdownText.Visibility = Visibility.Collapsed;

            StatusText.Text = "DETECTION OFF";
            StatusText.Foreground = (Brush)FindResource("DisabledBrush");

            ProgressArc.Stroke = (Brush)FindResource("DisabledBrush");
            ArcGlow.Opacity = 0;
            GlowEllipse.Opacity = 0;
            SetArcProgress(1.0);
        }

        private void DurationDownButton_Click(object sender, RoutedEventArgs e)
        {
            _cooldownSeconds = Math.Max(MinCooldownSeconds, Math.Round(_cooldownSeconds - 0.5, 1));
            SyncDurationText();
        }

        private void DurationUpButton_Click(object sender, RoutedEventArgs e)
        {
            _cooldownSeconds = Math.Min(MaxCooldownSeconds, Math.Round(_cooldownSeconds + 0.5, 1));
            SyncDurationText();
        }

        private void SyncDurationText()
        {
            string label = _cooldownSeconds.ToString("0.0") + "s";
            DurationValueText.Text = label;
            DurationSubtitleText.Text = "Cooldown Duration: " + label;
        }

        private void RebindKeyButton_Click(object sender, RoutedEventArgs e)
        {
            _isListeningForRebind = true;
            _eIsPhysicallyDown = false;
            RebindKeyButton.Content = "...";
        }

        private void CompleteRebind(int vkCode)
        {
            if (!_isListeningForRebind) return;

            _isListeningForRebind = false;
            _boundVkCode = vkCode;
            _eIsPhysicallyDown = false;

            RebindKeyButton.Content = GetKeyDisplayName(vkCode);

            if (_isDetectionEnabled && !_isOnCooldown)
            {
                StatusText.Text = "PRESS  " + GetKeyDisplayName(vkCode) + "  TO  START";
            }
        }

        private static string GetKeyDisplayName(int vkCode)
        {
            try
            {
                Key key = KeyInterop.KeyFromVirtualKey(vkCode);
                return key.ToString().ToUpperInvariant();
            }
            catch
            {
                return "KEY";
            }
        }

        // ---------------- Window chrome ----------------

        private void Window_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ButtonState == MouseButtonState.Pressed)
            {
                DragMove();
            }
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
